import Axios from 'axios'
// import Vue from 'vue'
import Point from './_helper.js'
export default {
    state: {
        all_points: [],
        parts_points_by_ids: [],
        all_parts_points: []
    },
    mutations: {
        all_points(state, payload) {
            for (let i = 0; i < payload.length; i++) {
                payload[i].index = i
                state.all_points.push(payload[i])
            }
        },
        create_point(state, payload) {
            if (state.all_points.length != 0) {
                payload.index = state.all_points[state.all_points.length - 1].index + 1;
            } else {
                payload.index = 0;
            }
            state.all_points.push(payload)
        },
        delete_point(state, index) {
            for (let i = 0; i < state.all_points.length; i++) {
                if (state.all_points[i].index === index) {
                    state.all_points.splice(i, 1);
                }
            }
        },
        update_point(state, { index, data }) {
            for (let i = 0; i < state.all_points.length; i++) {
                if (state.all_points[i].index === index) {
                    state.all_points[i].class = data.class
                    state.all_points[i].type = data.type
                    state.all_points[i].hint = data.hint
                    state.all_points[i].name = data.name
                    if (data.relatedPoint != undefined) {
                        state.all_points[i].relatedPoint = data.relatedPoint
                    }
                }
            }
        },
        clear_points_list(state) {
            state.all_points = []
        },
        // 
        load_all_parts_points(state, payload) {
            state.all_parts_points = payload
        }
    },
    actions: {
        async all_points({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)
            if (payload.related === 'skeleton') {

                try {
                    const res = await Axios.get("static/data_base/skeleton_points.json")
                    const data = res.data
                    const item = data.filter(item => item.skeletonId === parseInt(payload.id))

                    commit('all_points', item)
                    commit('setLoading', false)
                } catch {
                    commit('setLoading', false)
                    commit('setError', 'error')
                }
            } else if (payload.related === 'part') {

                try {
                    const res = await Axios.get("static/data_base/part_points.json")
                    const data = res.data
                    const item = data.filter(item => item.partId === parseInt(payload.id))

                    commit('all_points', item)
                    commit('setLoading', false)
                } catch {
                    commit('setLoading', false)
                    commit('setError', 'error')
                }
            } else if (payload.related === 'product') {

                try {
                    const res = await Axios.get("static/data_base/product_points.json")
                    const data = res.data
                    const item = data.filter(item => item.productId === parseInt(payload.id))

                    commit('all_points', item)
                    commit('setLoading', false)
                } catch {
                    commit('setLoading', false)
                    commit('setError', 'error')
                }
            }
        },
        create_point({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)
            const point = new Point(payload)

            try {
                commit('create_point', point)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        delete_point({ commit }, index) {
            commit('clearError')
            commit('setLoading', true)

            try {
                commit('delete_point', index)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        update_point({ commit }, { index, data }) {
            commit('clearError')
            commit('setLoading', true)

            try {
                commit('update_point', { index, data })
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        clear_points_list({ commit }) {
            commit('clearError')
            commit('setLoading', true)

            try {
                commit('clear_points_list')
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        // 
        async load_all_parts_points({ commit }) {
            commit('clearError')
            commit('setLoading', true)

            try {
                const res = await Axios.get("static/data_base/part_points.json")
                const data = res.data
                    // const items = []
                    // for (let i = 0; i < data.length; i++) {
                    //     for (let j = 0; j < payload.length; j++) {
                    //         if (data[i].partId === parseInt(payload[j])) {
                    //             items.push(data[i])
                    //         }
                    //     }
                    // }
                commit('load_all_parts_points', data)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        }
    },
    getters: {
        all_points(state) {
            return state.all_points
        },
        parts_points_by_ids(state) {
            return state.parts_points_by_ids
        },
        all_parts_points(state) {
            return state.all_parts_points
        }
    }
}