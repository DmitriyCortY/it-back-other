export default class Point {
    constructor(data) {
        this.id = data.id || null
        if (data.class != undefined && data.class) {
            this.class = data.class
        }
        if (data.hint != undefined && data.hint) {
            this.hint = data.hint
        }
        if (data.name != undefined && data.name) {
            this.name = data.name
        }
        if (data.pos != undefined && data.pos) {
            this.pos = data.pos
        }
        if (data.relatedPoint != undefined && data.relatedPoint != null) {
            this.relatedPoint = data.relatedPoint
        }
        if (data.side != undefined) {
            this.side = data.side
        }
        if (data.skeletonId != undefined) {
            this.skeletonId = data.skeletonId
        }
        if (data.type != undefined) {
            this.type = data.type
        }
    }
}