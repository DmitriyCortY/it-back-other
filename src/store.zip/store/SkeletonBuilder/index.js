import Axios from 'axios'
export default {
    state: {
        all_skeletons_data: [],
        skeleton_data_by_id: null
    },
    mutations: {
        load_all_skeletons_data(state, payload) { // paylaod === data
            state.all_skeletons_data = payload
        },
        load_skeleton_data_by_id(state, payload) { // paylaod === data
            state.skeleton_data_by_id = payload
        },
        create_skeleton(state, payload) { // paylaod === data
            state.all_skeletons_data.push(payload)
        },
        delete_skeleton(state, paylaod) { // payload === id
            for (let i = 0; i < state.all_skeletons_data.length; i++) {
                if (state.all_skeletons_data[i].id === paylaod) {
                    state.all_skeletons_data.splice(i, 1)
                }
            }
        },
        update_skeleton(state, paylaod) { // paylaod === data
            for (let i = 0; i < state.all_skeletons_data.length; i++) {
                if (state.all_skeletons_data[i].id === paylaod) {
                    state.all_skeletons_data[i].name = paylaod.name
                    state.all_skeletons_data[i].weight = paylaod.weight
                }
            }
        }
    },
    actions: {
        async load_all_skeletons_data({ commit }) {
            commit('clearError')
            commit('setLoading', true)
            try {
                const res = await Axios.get("static/data_base/skeleton.json")
                const data = res.data

                commit('load_all_skeletons_data', data)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async load_skeleton_data_by_id({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)

            try {
                const res = await Axios.get("static/data_base/skeleton.json")
                const data = res.data
                const currentDataById = data.filter(item => parseInt(item.id) === parseInt(payload))

                commit('load_skeleton_data_by_id', currentDataById)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async create_skeleton({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)

            try {
                await Axios.get("static/data_base/skeleton.json", payload)

                commit('create_skeleton', payload)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async delete_skeleton({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)
            try {
                await Axios.get("static/data_base/skeleton.json", { id: parseInt(payload) })

                commit('delete_skeleton', parseInt(payload))
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async update_skeleton({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)
            try {
                await Axios.get("static/data_base/skeleton.json", { id: parseInt(payload) })

                commit('update_skeleton', parseInt(payload))
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        }
    },
    getters: {
        all_skeletons_data(state) {
            return state.all_skeletons_data
        },
        skeleton_data_by_id(state) {
            if (state.skeleton_data_by_id != null) {
                return state.skeleton_data_by_id[0]
            }
        }
    }
}