import Axios from 'axios'
export default {
    state: {
        all_parts_data: [],
        part_data_by_id: [],
        parts_data_by_ids: []
    },
    mutations: {
        load_all_parts_data(state, payload) {
            state.all_parts_data = payload
        },
        load_part_data_by_id(state, payload) {
            state.part_data_by_id = payload
        },
        load_parts_data_by_ids(state, payload) {
            state.parts_data_by_ids = payload
        },
        create_part(state, payload) { // paylaod === data
            state.all_parts_data.push(payload)
        },
        delete_part(state, paylaod) { // payload === id
            for (let i = 0; i < state.all_parts_data.length; i++) {
                if (state.all_parts_data[i].id === paylaod) {
                    state.all_parts_data.splice(i, 1)
                }
            }
        },
        update_part(state, paylaod) { // paylaod === data
            for (let i = 0; i < state.all_parts_data.length; i++) {
                if (state.all_parts_data[i].id === paylaod) {
                    state.all_parts_data[i].name = paylaod.name
                    state.all_parts_data[i].weight = paylaod.weight
                }
            }
        }
    },
    actions: {
        async load_all_parts_data({ commit }) {
            commit('clearError')
            commit('setLoading', true)
            try {
                const res = await Axios.get("static/data_base/part.json")
                const data = res.data

                commit('load_all_parts_data', data)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async load_part_data_by_id({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)

            try {
                const res = await Axios.get("static/data_base/part.json")
                const data = res.data
                const currentDataById = data.filter(item => parseInt(item.id) === parseInt(payload))

                commit('load_part_data_by_id', currentDataById)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async load_parts_data_by_ids({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)

            try {
                const res = await Axios.get("static/data_base/part.json")
                const data = res.data
                const currentDatasById = []
                for (let i = 0; i < data.length; i++) {
                    for (let j = 0; j < payload.length; j++) {
                        if (data[i].id === payload[j]) {
                            currentDatasById.push(data[i])
                        }
                    }
                }

                commit('load_parts_data_by_ids', currentDatasById)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async create_part({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)

            try {
                await Axios.get("static/data_base/part.json", payload)

                commit('create_part', payload)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async delete_part({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)
            try {
                await Axios.get("static/data_base/part.json", { id: parseInt(payload) })

                commit('delete_part', parseInt(payload))
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async update_part({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)
            try {
                await Axios.get("static/data_base/part.json", { id: parseInt(payload) })

                commit('update_part', parseInt(payload))
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        }
    },
    getters: {
        all_parts_data(state) {
            return state.all_parts_data
        },
        part_data_by_id(state) {
            return state.part_data_by_id
        },
        parts_data_by_ids(state) {
            return state.parts_data_by_ids
        }
    }
}