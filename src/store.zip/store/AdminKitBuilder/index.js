import Axios from 'axios'
export default {
    state: {
        admin_kit_list: [],
        akb_skeleton_data: [],
        akb_skeleton_points_data: [],
        akb_all_products_data: [],
        akb_all_products_points_data: [],
        akb_attach_first_level: {},
        akb_attach_next_level: {},
        akb_end_loaded: false
    },
    mutations: {
        akb_drop_store(state) {
            state.admin_kit_list = []
            state.akb_skeleton_data = []
            state.akb_skeleton_points_data = []
            state.akb_all_products_data = []
            state.akb_all_products_points_data = []
            state.akb_attach_first_level = {}
            state.akb_attach_next_level = {}
            state.akb_end_loaded = false
        },
        load_admin_kit_list(state, payload) {
            state.admin_kit_list = payload
        },
        akb_skeleton_data(state, payload) {
            state.akb_skeleton_data = payload
        },
        akb_skeleton_points_data(state, payload) {
            state.akb_skeleton_points_data = payload
        },
        akb_all_products_data(state, payload) {
            state.akb_all_products_data = payload
        },
        akb_all_products_points_data(state, payload) {
            state.akb_all_products_points_data = payload
        },
        akb_attach_first_level(state, payload) {
            state.akb_attach_first_level = payload
        },
        akb_attach_next_level(state, payload) {
            state.akb_attach_next_level = payload
        },
        akb_end_loaded(state) {
            state.akb_end_loaded = true
        }
    },
    actions: {
        akb_drop_store({ commit }) {
            commit('akb_drop_store')
        },
        async load_admin_kit_list({ commit }) {
            commit('clearError')
            commit('setLoading', true)
            try {
                const res = await Axios.get("static/data_base/admin_kits.json")
                const data = res.data
                commit('load_admin_kit_list', data)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async load_akb_all_data({ commit }, payload) { // {skeleton_id: 12...}
            commit('clearError')
            commit('setLoading', true)

            try {
                // Получаем данные выбраного скелета 
                const all_skeletons = await Axios.get("static/data_base/skeleton.json")
                const skeleton_by_id = await all_skeletons.data.filter(item => parseInt(item.id) === parseInt(payload.skeleton_id))[0]

                // Получаем точки выбраного скелета 
                const all_skeletons_points = await Axios.get("static/data_base/skeleton_points.json")
                const current_skeleton_points = await all_skeletons_points.data.filter(item => parseInt(item.skeletonId) === parseInt(skeleton_by_id.id))

                // Получаем данные всех обвесов (второго типа)
                const all_products = await Axios.get("static/data_base/product.json")
                const all_products_data = all_products.data

                // Получаем точки всеx обвесов   
                const all_product_points = await Axios.get("static/data_base/product_points.json")
                const all_product_points_data = all_product_points.data

                // Получаем список подходящих обвесов первого уровня
                const merge_product_points_and_skeleton_points = async(products_list, products_points_list, skeleton_points_list) => {
                    let list = {
                        front: [],
                        back: []
                    }
                    for (let i = 0; i < products_list.length; i++) {
                        for (let j = 0; j < products_points_list.length; j++) {
                            for (let k = 0; k < skeleton_points_list.length; k++) {
                                if (
                                    parseInt(products_list[i].id) === parseInt(products_points_list[j].productId) &&
                                    products_points_list[j].class === skeleton_points_list[k].class &&
                                    products_points_list[j].side === skeleton_points_list[k].side &&
                                    products_points_list[j].type != skeleton_points_list[k].type &&
                                    products_points_list[j].type === "Minus"
                                ) {
                                    if (products_points_list[j].side === 'front') {
                                        list.front.push({
                                            product_data: products_list[i],
                                            product_point_data: products_points_list[j],
                                            skeleton_point_data: skeleton_points_list[k]
                                        })
                                    } else if (products_points_list[j].side === 'back') {
                                        list.back.push({
                                            product_data: products_list[i],
                                            product_point_data: products_points_list[j],
                                            skeleton_point_data: skeleton_points_list[k]
                                        })
                                    }
                                }
                            }
                        }
                    }
                    return list
                }
                const akb_attach_first_level = await merge_product_points_and_skeleton_points(all_products_data, all_product_points_data, current_skeleton_points)

                // Получаем список подходящих обвесов ВНУТРЕННИХ уровнЕЙ
                const merge_product_points_and_parent_product_points = async(products_list, products_points_list, parent_products_points_lsit) => {
                    let list = {
                        front: [],
                        back: []
                    }
                    for (let i = 0; i < products_list.length; i++) {
                        for (let j = 0; j < products_points_list.length; j++) {
                            for (let k = 0; k < parent_products_points_lsit.length; k++) {
                                if (
                                    parseInt(products_list[i].id) === parseInt(products_points_list[j].productId) &&
                                    products_points_list[j].class === parent_products_points_lsit[k].class &&
                                    products_points_list[j].side === parent_products_points_lsit[k].side &&
                                    products_points_list[j].type != parent_products_points_lsit[k].type &&
                                    products_points_list[j].type === "Minus"
                                ) {
                                    if (products_points_list[j].side === 'front') {
                                        list.front.push({
                                            product_data: products_list[i],
                                            product_point_data: products_points_list[j],
                                            parent_product_point_data: parent_products_points_lsit[k]
                                        })
                                    } else if (products_points_list[j].side === 'back') {
                                        list.back.push({
                                            product_data: products_list[i],
                                            product_point_data: products_points_list[j],
                                            parent_product_point_data: parent_products_points_lsit[k]
                                        })
                                    }
                                }
                            }
                        }
                    }
                    return list
                }
                const akb_attach_next_level = await merge_product_points_and_parent_product_points(all_products_data, all_product_points_data, all_product_points_data)



                await commit('akb_skeleton_data', skeleton_by_id)
                await commit('akb_skeleton_points_data', current_skeleton_points)
                await commit('akb_all_products_data', all_products_data)
                await commit('akb_all_products_points_data', all_product_points_data)
                await commit('akb_attach_first_level', akb_attach_first_level)
                await commit('akb_attach_next_level', akb_attach_next_level)

                await commit('akb_end_loaded')

                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        }

    },
    getters: {
        admin_kit_list(state) {
            return state.admin_kit_list
        },
        akb_skeleton_data(state) {
            return state.akb_skeleton_data
        },
        akb_skeleton_points_data(state) {
            return state.akb_skeleton_points_data
        },
        akb_all_products_data(state) {
            return state.akb_all_products_data
        },
        akb_all_products_points_data(state) {
            return state.akb_all_products_points_data
        },
        akb_attach_first_level(state) {
            return state.akb_attach_first_level
        },
        akb_attach_next_level(state) {
            return state.akb_attach_next_level
        },
        akb_end_loaded(state) {
            return state.akb_end_loaded
        }
    },
}