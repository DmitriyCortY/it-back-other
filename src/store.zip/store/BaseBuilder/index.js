// import Axios from 'axios'
// export default {
//     state: {
//         base_builder_list: [],
//         new_base_builder: [],
//         base_builder_by_id: null,
//         base_builder_attach_by_id: []
//     },
//     mutations: {
//         load_base_builder_list(state, payload) {
//             state.base_builder_list = payload
//         },
//         create_base_builder_attach(state, payload) {
//             state.new_base_builder = payload
//         },
//         load_base_builder_attach_by_id(state, payload) {
//             state.base_builder_attach_by_id = payload
//         },
//         load_base_builder_by_id(state, payload) {
//             state.base_builder_by_id = payload
//         },
//         base_store_clear(state) {
//             state.base_builder_list = []
//             state.new_base_builder = []
//             state.base_builder_by_id = null
//             state.base_builder_attach_by_id = []
//         }
//     },
//     actions: {
//         async load_base_builder_list({ commit }) {
//             commit('clearError')
//             commit('setLoading', true)
//             try {
//                 const res = await Axios.get("static/data_base/base.json")
//                 const data = res.data

//                 commit('load_base_builder_list', data)
//                 commit('setLoading', false)
//             } catch {
//                 commit('setLoading', false)
//                 commit('setError', 'error')
//             }
//         },
//         async load_base_builder_by_id({ commit }, payload) {
//             commit('clearError')
//             commit('setLoading', true)
//             try {
//                 const res = await Axios.get("static/data_base/base.json")
//                 const data = res.data
//                 const currentData = data.filter(item => parseInt(item.id) === parseInt(payload))
//                 commit('load_base_builder_by_id', currentData[0])
//                 commit('setLoading', false)
//             } catch {
//                 commit('setLoading', false)
//                 commit('setError', 'error')
//             }
//         },
//         async create_base_builder_attach({ commit }, payload) {
//             commit('clearError')
//             commit('setLoading', true)
//             try {
//                 const res = await Axios.get("static/data_base/base_points.json", payload)
//                 const data = res.data

//                 commit('create_base_builder_attach', data)
//                 commit('setLoading', false)
//             } catch {
//                 commit('setLoading', false)
//                 commit('setError', 'error')
//             }
//         },
//         async load_base_builder_attach_by_id({ commit }, payload) {
//             commit('clearError')
//             commit('setLoading', true)
//             try {
//                 const res = await Axios.get("static/data_base/base_points.json")
//                 const data = res.data
//                 commit('load_base_builder_attach_by_id', data[payload])
//                 commit('setLoading', false)
//             } catch {
//                 commit('setLoading', false)
//                 commit('setError', 'error')
//             }
//         },
//         base_store_clear({ commit }) {
//             commit('clearError')
//             commit('setLoading', true)
//             try {
//                 commit('base_store_clear')
//                 commit('setLoading', false)
//             } catch {
//                 commit('setLoading', false)
//                 commit('setError', 'error')
//             }
//         }
//     },
//     getters: {
//         base_builder_list(state) {
//             return state.base_builder_list
//         },
//         base_builder_attach_by_id(state) {
//             return state.base_builder_attach_by_id
//         },
//         base_builder_by_id(state) {
//             return state.base_builder_by_id
//         }
//     }
// }

import Axios from 'axios'
export default {
    state: {
        base_builder_list: [],
        bb_data: {},
        bb_skeleton_data: [],
        bb_skeleton_points: [],
        bb_parts_data: [],
        bb_parts_points: [],
        bb_list_relations_data_skeleton: [],
        bb_list_relations_data_part: [],
        bb_by_id: [],
        bb_all_loaded: false
    },
    mutations: {
        bb_drop(state) {
            state.base_builder_list = []
            state.bb_data = {}
            state.bb_skeleton_data = []
            state.bb_skeleton_points = []
            state.bb_parts_data = []
            state.bb_parts_points = []
            state.bb_list_relations_data_skeleton = []
            state.bb_list_relations_data_part = []
            state.bb_by_id = []
            state.bb_all_loaded = false
        },
        load_base_builder_list(state, payload) {
            state.base_builder_list = payload
        },
        load_test(state, paylaod) {
            state.test.push(paylaod)
        },
        load_bb_skeleton_data(state, payload) {
            state.bb_skeleton_data = payload
        },
        load_bb_skeleton_points(state, payload) {
            state.bb_skeleton_points = payload
        },
        load_bb_parts_data(state, payload) {
            state.bb_parts_data = payload
        },
        load_bb_parts_points(state, payload) {
            state.bb_parts_points = payload
        },
        load_bb_list_relations_data_skeleton(state, payload) {
            state.bb_list_relations_data_skeleton = payload
        },
        load_bb_list_relations_data_part(state, payload) {
            state.bb_list_relations_data_part = payload
        },
        create_bb(state, payload) {
            state.bb_by_id = payload
        },
        update_bb(state, payload) {
            state.bb_by_id = payload
        },
        load_bb(state, payload) {
            state.bb_data = payload
        },
        bb_by_id(state, payload) {
            state.bb_by_id = payload
        },
        bb_all_loaded(state) {
            setTimeout(() => {
                state.bb_all_loaded = true
            }, 0)
        }
    },
    actions: {
        async load_base_builder_list({ commit }) {
            commit('clearError')
            commit('setLoading', true)
            try {
                const res = await Axios.get("static/data_base/base.json")
                const data = res.data

                commit('load_base_builder_list', data)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async load_bb_data({ commit, state }, payload) {
            commit('clearError')
            commit('setLoading', true)

            try {
                // Получаем данные выбраного скелета 
                const all_skeletons = await Axios.get("static/data_base/skeleton.json")
                const skeleton_by_id = await all_skeletons.data.filter(item => parseInt(item.id) === parseInt(payload.skeleton_id))[0]
                commit('load_bb_skeleton_data', skeleton_by_id)

                // Получаем точки выбраного скелета 
                const all_skeletons_points = await Axios.get("static/data_base/skeleton_points.json")
                const current_skeleton_points = await all_skeletons_points.data.filter(item => parseInt(item.skeletonId) === parseInt(skeleton_by_id.id))
                commit('load_bb_skeleton_points', current_skeleton_points)

                // Получаем данные всех обвесов (второго типа)
                const all_parts = await Axios.get("static/data_base/part.json")
                const all_parts_data = all_parts.data
                commit('load_bb_parts_data', all_parts_data)

                // Получаем точки всеx обвесов   
                const all_parts_points = await Axios.get("static/data_base/part_points.json")
                const all_parts_points_data = all_parts_points.data
                commit('load_bb_parts_points', all_parts_points_data)

                const merge_parts_and_their_points = (parts, parts_points, current_skeleton_points) => {
                    let list = {
                        front: [],
                        back: []
                    }
                    for (let i = 0; i < parts.length; i++) {
                        for (let j = 0; j < parts_points.length; j++) {
                            for (let k = 0; k < current_skeleton_points.length; k++) {
                                if (
                                    parseInt(parts[i].id) === parseInt(parts_points[j].partId) &&
                                    parts_points[j].type === "Minus" &&
                                    parts_points[j].class === current_skeleton_points[k].class &&
                                    parts_points[j].side === current_skeleton_points[k].side &&
                                    parts_points[j].type != current_skeleton_points[k].type
                                ) {
                                    if (parts_points[j].side === 'front') {
                                        list.front.push({
                                            skeleton_id: payload.skeleton_id,
                                            skeleton_points_id: current_skeleton_points[k].id,
                                            part_id: parts[i].id,
                                            part_points_id: parts_points[j].id
                                        })
                                    } else if (parts_points[j].side === 'back') {
                                        list.back.push({
                                            skeleton_id: payload.skeleton_id,
                                            skeleton_points_id: current_skeleton_points[k].id,
                                            part_id: parts[i].id,
                                            part_points_id: parts_points[j].id
                                        })
                                    }
                                }
                            }
                        }
                    }
                    return list
                }
                const merge_parts_and_their_points_2 = (parts, parts_points, parent_parts_points) => {
                    let list = {
                        front: [],
                        back: []
                    }
                    for (let i = 0; i < parts.length; i++) {
                        for (let j = 0; j < parts_points.length; j++) {
                            for (let k = 0; k < parent_parts_points.length; k++) {
                                if (
                                    parseInt(parts[i].id) === parseInt(parts_points[j].partId) &&
                                    parts_points[j].type === "Minus" &&
                                    parts_points[j].class === parent_parts_points[k].class &&
                                    parts_points[j].side === parent_parts_points[k].side &&
                                    parts_points[j].type != parent_parts_points[k].type
                                ) {
                                    if (parts_points[j].side === 'front') {
                                        list.front.push({
                                            skeleton_id: payload.skeleton_id,
                                            parent_part_point_id: parent_parts_points[k].id,
                                            part_id: parts[i].id,
                                            part_points_id: parts_points[j].id
                                        })
                                    } else if (parts_points[j].side === 'back') {
                                        list.back.push({
                                            skeleton_id: payload.skeleton_id,
                                            parent_part_point_id: parent_parts_points[k].id,
                                            part_id: parts[i].id,
                                            part_points_id: parts_points[j].id
                                        })
                                    }
                                }
                            }
                        }
                    }
                    return list
                }

                const related_list_for_skeleton = await merge_parts_and_their_points(all_parts_data, all_parts_points_data, current_skeleton_points)
                commit('load_bb_list_relations_data_skeleton', related_list_for_skeleton)

                const related_list_for_parts = await merge_parts_and_their_points_2(all_parts_data, all_parts_points_data, all_parts_points_data)
                commit('load_bb_list_relations_data_part', related_list_for_parts)

                if (Object.keys(state.bb_list_relations_data_skeleton).length > 0, Object.keys(state.bb_list_relations_data_part).length > 0) {
                    commit('bb_all_loaded', [related_list_for_skeleton, related_list_for_parts])
                }

                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        drop_bb_data({ commit }) {
            commit('bb_drop')
        },
        async save_bb_relations({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)
            try {
                console.log(payload)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async load_bb({ commit, dispatch }, payload) {
            commit('clearError')
            commit('setLoading', true)
            try {
                const base = await Axios.get('static/data_base/base_data.json')
                const base_data = await base.data.filter(item => parseInt(item.base_id) === parseInt(payload))[0]

                await dispatch('load_bb_data', { skeleton_id: base_data.skeleton_id })
                commit('load_bb', base_data)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async create_bb({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)
            try {
                if (!payload.id) {
                    let get_random_id = max => {
                        return Math.floor(Math.random() * Math.floor(max));
                    }
                    let data = {
                            name: payload.name,
                            skeleton: payload.skeleton_id,
                            category: payload.category,
                            description: payload.description
                        }
                        // const bb_create = await Axios.post('static/data_base/base_points.json', data)
                    const bb_create = {...data, id: get_random_id(1000) }
                    commit('create_bb', bb_create)
                }
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async update_bb({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)
            try {
                let data = {
                        name: payload.name,
                        skeleton: payload.skeleton_id,
                        category: payload.category,
                        description: payload.description,
                        id: payload.id
                    }
                    // const bb_update = await Axios.post('static/data_base/base_points.json', data)
                commit('update_bb', data)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async load_bb_by_id({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)
            try {
                const bb_list = await Axios.get('static/data_base/base.json')
                const bb_by_id = await bb_list.data.filter(item => parseInt(item.id) === parseInt(payload))[0]
                commit('bb_by_id', bb_by_id)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        }
    },
    getters: {
        base_builder_list(state) {
            return state.base_builder_list
        },
        bb_skeleton_data(state) {
            return state.bb_skeleton_data
        },
        bb_skeleton_points(state) {
            return state.bb_skeleton_points
        },
        bb_parts_data(state) {
            return state.bb_parts_data
        },
        bb_parts_points(state) {
            return state.bb_parts_points
        },
        bb_list_relations_data_skeleton(state) {
            return state.bb_list_relations_data_skeleton
        },
        bb_list_relations_data_part(state) {
            return state.bb_list_relations_data_part
        },
        bb_data(state) {
            return state.bb_data
        },
        bb_by_id(state) {
            return state.bb_by_id
        },
        bb_all_loaded(state) {
            return state.bb_all_loaded
        }
    }
}