import Axios from 'axios'
export default {
    state: {
        all_products_data: [],
        product_data_by_id: [],
        products_data_by_ids: []
    },
    mutations: {
        load_all_products_data(state, payload) {
            state.all_products_data = payload
        },
        load_product_data_by_id(state, payload) {
            state.product_data_by_id = payload
        },
        load_products_data_by_ids(state, payload) {
            state.products_data_by_ids = payload
        },
        create_product(state, payload) { // paylaod === data
            state.all_products_data.push(payload)
        },
        delete_product(state, paylaod) { // payload === id
            for (let i = 0; i < state.all_products_data.length; i++) {
                if (state.all_products_data[i].id === paylaod) {
                    state.all_products_data.splice(i, 1)
                }
            }
        },
        update_product(state, paylaod) { // paylaod === data
            for (let i = 0; i < state.all_products_data.length; i++) {
                if (state.all_products_data[i].id === paylaod) {
                    state.all_products_data[i].name = paylaod.name
                    state.all_products_data[i].weight = paylaod.weight
                }
            }
        }
    },
    actions: {
        async load_all_products_data({ commit }) {
            commit('clearError')
            commit('setLoading', true)
            try {
                const res = await Axios.get("static/data_base/product.json")
                const data = res.data

                commit('load_all_products_data', data)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async load_product_data_by_id({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)

            try {
                const res = await Axios.get("static/data_base/product.json")
                const data = res.data
                const currentDataById = data.filter(item => parseInt(item.id) === parseInt(payload))

                commit('load_product_data_by_id', currentDataById)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async load_products_data_by_ids({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)

            try {
                const res = await Axios.get("static/data_base/product.json")
                const data = res.data
                const currentDatasById = []
                for (let i = 0; i < data.length; i++) {
                    for (let j = 0; j < payload.length; j++) {
                        if (data[i].id === payload[j]) {
                            currentDatasById.push(data[i])
                        }
                    }
                }

                commit('load_products_data_by_ids', currentDatasById)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async create_product({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)

            try {
                await Axios.get("static/data_base/product.json", payload)

                commit('create_product', payload)
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async delete_product({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)
            try {
                await Axios.get("static/data_base/product.json", { id: parseInt(payload) })

                commit('delete_product', parseInt(payload))
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        },
        async update_product({ commit }, payload) {
            commit('clearError')
            commit('setLoading', true)
            try {
                await Axios.get("static/data_base/product.json", { id: parseInt(payload) })

                commit('update_product', parseInt(payload))
                commit('setLoading', false)
            } catch {
                commit('setLoading', false)
                commit('setError', 'error')
            }
        }
    },
    getters: {
        all_products_data(state) {
            return state.all_products_data
        },
        product_data_by_id(state) {
            return state.product_data_by_id
        },
        products_data_by_ids(state) {
            return state.products_data_by_ids
        }
    }
}